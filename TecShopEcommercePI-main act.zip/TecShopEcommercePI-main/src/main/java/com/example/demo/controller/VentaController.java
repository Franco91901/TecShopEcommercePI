package com.example.demo.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.VentaDetalle;
import com.example.demo.model.ItemCarrito;
import com.example.demo.model.Usuario;
import com.example.demo.model.Venta;
import com.example.demo.model.Producto;
import com.example.demo.service.ProductoService;
import com.example.demo.service.VentaService;

import jakarta.servlet.http.HttpSession;

@Controller
public class VentaController {

    private final VentaService ventaService;
    private final ProductoService productoService;

    public VentaController(VentaService ventaService, ProductoService productoService) {
        this.ventaService = ventaService;
        this.productoService = productoService;
    }

    // -----------------------------------------------------------
    // 1) MOSTRAR CHECKOUT
    // -----------------------------------------------------------
    @GetMapping("/checkout")
    public String checkout(HttpSession session, Model model) {

        List<ItemCarrito> carrito = (List<ItemCarrito>) session.getAttribute("carrito");

        if (carrito == null || carrito.isEmpty()) {
            return "redirect:/carrito";
        }

        double total = carrito.stream()
                .mapToDouble(i -> i.getPrecio() * i.getCantidad())
                .sum();

        model.addAttribute("carrito", carrito);
        model.addAttribute("total", total);

        return "carrito/checkout";
    }

    // -----------------------------------------------------------
    // 2) PROCESAR COMPRA
    // -----------------------------------------------------------
    @PostMapping("/procesar-compra")
    public String procesarCompra(HttpSession session) {

        Usuario usuario = (Usuario) session.getAttribute("usuario");
        List<ItemCarrito> carrito = (List<ItemCarrito>) session.getAttribute("carrito");

        if (usuario == null)
            return "redirect:/login";

        if (carrito == null || carrito.isEmpty())
            return "redirect:/carrito";

        // Crear venta
        Venta venta = new Venta();
        venta.setUsuario(usuario);
        venta.setFecha(LocalDateTime.now());

        double total = carrito.stream()
                .mapToDouble(i -> i.getPrecio() * i.getCantidad())
                .sum();

        venta.setTotal(total);

        // Crear detalles
        for (ItemCarrito item : carrito) {

            Producto p = productoService.buscarPorId(item.getIdProducto()).orElse(null);

            if (p == null) continue;

            VentaDetalle d = new VentaDetalle();
            d.setProductoId(p.getId());
            d.setNombreProducto(p.getName());
            d.setPrecioUnitario(item.getPrecio());
            d.setCantidad(item.getCantidad());
            d.setSubtotal(item.getPrecio() * item.getCantidad());
            d.setVenta(venta);

            venta.getDetalles().add(d);
        }

        // Guardar venta y detalles
        ventaService.registrar(venta);

        // Vaciar carrito
        session.setAttribute("carrito", null);

        return "redirect:/carrito/exito";
    }

    // -----------------------------------------------------------
    // 3) PANTALLA DE ÉXITO
    // -----------------------------------------------------------
    @GetMapping("/carrito/exito")
    public String exito() {
        return "carrito/exito";
    }
}
