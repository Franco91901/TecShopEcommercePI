package com.example.demo.service;

import java.util.List;
import org.springframework.stereotype.Service;

import com.example.demo.model.Usuario;
import com.example.demo.repository.UsuarioRepository;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository repo;

    // Inyección por constructor
    public UsuarioServiceImpl(UsuarioRepository repo) {
        this.repo = repo;
    }

    @Override
    public Usuario registrar(Usuario usuario) {
        return repo.save(usuario);
    }

    @Override
    public Usuario login(String correo, String contrasena) {
        Usuario u = repo.findByCorreo(correo);
        if (u != null && u.getContrasena().equals(contrasena)) {
            return u;
        }
        return null;
    }

    @Override
    public List<Usuario> listarTodos() {
        return repo.findAll();
    }

    @Override
    public Usuario buscarPorId(Integer id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public Usuario actualizar(Usuario usuario) {
        return repo.save(usuario);
    }

    @Override
    public void eliminar(Integer id) {
        repo.deleteById(id);
    }

    // ⭐ NUEVOS MÉTODOS DE VALIDACIÓN
    @Override
    public boolean existeCorreo(String correo) {
        return repo.existsByCorreo(correo);
    }

    @Override
    public boolean existeDni(String dni) {
        return repo.existsByDni(dni);
    }
}
