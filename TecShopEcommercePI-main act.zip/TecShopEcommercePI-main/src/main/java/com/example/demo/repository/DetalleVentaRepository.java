package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.VentaDetalle;

@Repository
public interface DetalleVentaRepository extends JpaRepository<VentaDetalle, Long> {

    // Obtiene todos los detalles de una venta
    List<VentaDetalle> findByVentaId(Long ventaId);

    // Opcional: sumar total de una venta mediante detalle
    // (solo si algún día lo necesitas)
    // @Query("SELECT SUM(d.precio * d.cantidad) FROM DetalleVenta d WHERE d.venta.id = :ventaId")
    // Double calcularTotalPorVenta(Long ventaId);
}
