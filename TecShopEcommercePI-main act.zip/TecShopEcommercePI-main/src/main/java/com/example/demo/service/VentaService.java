package com.example.demo.service;

import com.example.demo.model.Venta;
import java.util.List;

public interface VentaService {

    Venta registrar(Venta venta);

    List<Venta> listar();

    Venta obtenerPorId(Long id);
}
