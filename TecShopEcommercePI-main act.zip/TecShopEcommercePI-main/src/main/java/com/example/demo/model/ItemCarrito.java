package com.example.demo.model;

public class ItemCarrito {

    private Long idProducto;
    private String nombre;
    private double precio;
    private int cantidad;
    private String imagen;

    public ItemCarrito() {
    }

    public ItemCarrito(Long idProducto, String nombre, double precio, int cantidad, String imagen) {
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.imagen = imagen;
    }

    // ===== Getters y Setters =====

    public Long getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Long idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    // ===== Método útil para total por item =====
    public double getSubtotal() {
        return this.precio * this.cantidad;
    }

    @Override
    public String toString() {
        return "ItemCarrito{" +
                "idProducto=" + idProducto +
                ", nombre='" + nombre + '\'' +
                ", precio=" + precio +
                ", cantidad=" + cantidad +
                ", imagen='" + imagen + '\'' +
                '}';
    }
}
