package com.example.demo.service;

import org.springframework.stereotype.Service;
import com.example.demo.model.Venta;
import com.example.demo.repository.VentaRepository;

import java.util.List;

@Service
public class VentaServiceImpl implements VentaService {

    private final VentaRepository repo;

    public VentaServiceImpl(VentaRepository repo) {
        this.repo = repo;
    }

    @Override
    public Venta registrar(Venta venta) {
        if (venta == null) {
            throw new IllegalArgumentException("La venta no puede ser null");
        }
        return repo.save(venta);
    }

    @Override
    public List<Venta> listar() {
        return repo.findAll();
    }

    @Override
    public Venta obtenerPorId(Long id) {
        return repo.findById(id).orElse(null);
    }
}
