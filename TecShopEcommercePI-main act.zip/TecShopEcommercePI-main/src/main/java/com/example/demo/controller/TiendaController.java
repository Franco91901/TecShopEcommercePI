package com.example.demo.controller;

import com.example.demo.model.Producto;
import com.example.demo.service.ProductoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/tienda")
public class TiendaController {

    private final ProductoService productoService;

    public TiendaController(ProductoService productoService) {
        this.productoService = productoService;
    }

    // 🛒 LISTA DE PRODUCTOS
    @GetMapping
    public String tienda(Model model) {

        List<Producto> productos = productoService.listarTodos();
        model.addAttribute("productos", productos);

        return "tienda/index";  // Vista: templates/tienda/index.html
    }

    // 🔍 DETALLE DE PRODUCTO
    @GetMapping("/detalle/{id}")
    public String detalle(@PathVariable Long id, Model model) {

        Producto producto = productoService.buscarPorId(id).orElse(null);

        if (producto == null) {
            // Si no existe, llevamos a tienda con un mensaje opcional
            model.addAttribute("error", "El producto no existe.");
            return "redirect:/tienda";
        }

        model.addAttribute("producto", producto);
        return "tienda/detalle"; // Vista: templates/tienda/detalle.html
    }
}
