package com.example.demo.controller;

import com.example.demo.model.Usuario;
import com.example.demo.repository.RolRepository;
import com.example.demo.service.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/perfiles")
public class ClienteController {

    private final RolRepository rolRepository;
    private final UsuarioService usuarioService;

    public ClienteController(UsuarioService usuarioService, RolRepository rolRepository) {
        this.usuarioService = usuarioService;
        this.rolRepository = rolRepository;
    }

    @GetMapping
    public String listarPerfiles(Model model) {
        model.addAttribute("clientes", usuarioService.listarTodos());
        return "admin/perfiles";
    }

    @GetMapping("/editar/{id}")
    public String editarPerfil(@PathVariable Integer id, Model model) {
        Usuario usuario = usuarioService.buscarPorId(id);

        if (usuario == null)
            return "redirect:/admin/perfiles?error=notfound";

        model.addAttribute("usuario", usuario);
        model.addAttribute("roles", rolRepository.findAll());

        return "admin/editar-perfil";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Usuario usuario) {

        Usuario original = usuarioService.buscarPorId(usuario.getIdUsuario());

        // Mantener contraseña si no se ingresa una nueva
        if (usuario.getContrasena() == null || usuario.getContrasena().isBlank()) {
            usuario.setContrasena(original.getContrasena());
        }

        usuarioService.actualizar(usuario);
        return "redirect:/admin/perfiles?editado=true";
    }

    @GetMapping("/desactivar/{id}")
    public String desactivar(@PathVariable int id) {
        usuarioService.desactivar(id);
        return "redirect:/admin/perfiles?desactivado=true";
    }
}
