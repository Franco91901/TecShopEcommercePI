package com.example.demo.controller;

import com.example.demo.model.Producto;
import com.example.demo.service.ProductoAdminService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/productos")  // Ruta base para el panel admin
public class ProductoAdminController {

    private final ProductoAdminService productoService;

    // Inyectamos directamente el service (constructor)
    public ProductoAdminController(ProductoAdminService productoService) {
        this.productoService = productoService;
    }

    // ===============================
    // LISTAR PRODUCTOS
    // ===============================
    @GetMapping
    public String listar(Model model) {
        model.addAttribute("productos", productoService.listar());
        return "admin/productos";  // templates/admin/productos.html
    }

    // ===============================
    // FORMULARIO NUEVO
    // ===============================
    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("producto", new Producto());
        model.addAttribute("titulo", "Nuevo Producto");
        return "admin/formulario"; // templates/admin/formulario.html
    }

    // ===============================
    // GUARDAR (CREAR / EDITAR)
    // ===============================
    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("producto") Producto producto,
                          BindingResult result,
                          Model model) {

        // Si hay errores de validación (NotBlank, NotNull, etc.)
        if (result.hasErrors()) {
            String titulo = (producto.getId() == null)
                    ? "Nuevo Producto"
                    : "Editar Producto";

            model.addAttribute("titulo", titulo);
            // Volvemos al mismo formulario con los errores
            return "admin/formulario";
        }

        // Si todo OK, guardamos y redirigimos al listado
        productoService.guardar(producto);
        return "redirect:/admin/productos";
    }

    // ===============================
    // EDITAR PRODUCTO
    // ===============================
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {

        Producto producto;
        try {
            producto = productoService.obtenerPorId(id);  // lanza RuntimeException si no existe
        } catch (RuntimeException e) {
            return "redirect:/admin/productos?error=noExiste";
        }

        model.addAttribute("producto", producto);
        model.addAttribute("titulo", "Editar Producto");
        return "admin/formulario";
    }

    // ===============================
    // ELIMINAR PRODUCTO
    // ===============================
    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        productoService.eliminar(id);
        return "redirect:/admin/productos";
    }
}
