package com.example.demo.controller;

import com.example.demo.model.Usuario;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PerfilClienteController {

    // PERFIL DEL CLIENTE
    @GetMapping("/perfil")
    public String perfil(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario == null) {
            return "redirect:/login";
        }

        model.addAttribute("usuario", usuario);
        return "cliente/perfil";  // templates/cliente/perfil.html
    }

    // MIS COMPRAS
    @GetMapping("/mis-compras")
    public String misCompras(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario == null) {
            return "redirect:/login";
        }

        // Más adelante aquí cargas compras reales
        // model.addAttribute("compras", compraService.listarPorUsuario(usuario.getIdUsuario()));

        return "cliente/mis-compras";  // templates/cliente/mis-compras.html
    }
}
