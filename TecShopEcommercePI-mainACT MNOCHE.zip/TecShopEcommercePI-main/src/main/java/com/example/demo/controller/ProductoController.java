package com.example.demo.controller;

import com.example.demo.model.Producto;
import com.example.demo.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/producto")
public class ProductoController {

    @Autowired
    private ProductoService service;

    // ===============================
    // LISTAR
    // ===============================
    @GetMapping
    public String listar(Model model) {
        model.addAttribute("productos", service.listar());
        return "producto/lista";   // vista producto/lista.html
    }

    // ===============================
    // FORMULARIO NUEVO
    // ===============================
    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("producto", new Producto());
        return "producto/formulario"; // vista producto/formulario.html
    }

    // ===============================
    // GUARDAR (CREAR / EDITAR)
    // ===============================
    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Producto producto) {
        service.guardar(producto);
        return "redirect:/producto";
    }

    // ===============================
    // EDITAR
    // ===============================
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {

        Producto producto = service.obtenerPorId(id).orElse(null);

        if (producto == null) {
            return "redirect:/producto?error=noExiste";
        }

        model.addAttribute("producto", producto);
        return "producto/formulario";
    }

    // ===============================
    // ELIMINAR
    // ===============================
    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return "redirect:/producto";
    }
}
