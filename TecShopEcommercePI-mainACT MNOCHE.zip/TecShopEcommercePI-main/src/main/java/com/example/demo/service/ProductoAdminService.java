package com.example.demo.service;

import com.example.demo.model.Producto;
import com.example.demo.repository.ProductoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoAdminService {

    private final ProductoRepository repo;

    public ProductoAdminService(ProductoRepository repo) {
        this.repo = repo;
    }

    // ===============================
    // LISTAR TODOS LOS PRODUCTOS
    // ===============================
    public List<Producto> listar() {
        return repo.findAll();
    }

    // ===============================
    // GUARDAR (CREAR O EDITAR)
    // ===============================
    public Producto guardar(Producto producto) {

        if (producto.getId() != null) {
            // Editar existente
            Producto existente = repo.findById(producto.getId())
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

            existente.setNombre(producto.getNombre());
            existente.setDescripcion(producto.getDescripcion());
            existente.setPrecio(producto.getPrecio());
            existente.setMarca(producto.getMarca());
            existente.setModelo(producto.getModelo());
            existente.setAnio(producto.getAnio());
            existente.setRam(producto.getRam());
            existente.setAlmacenamiento(producto.getAlmacenamiento());
            existente.setProcesador(producto.getProcesador());
            existente.setImagen(producto.getImagen());

            return repo.save(existente);
        }

        // Nuevo producto
        return repo.save(producto);
    }

    // ===============================
    // OBTENER POR ID
    // ===============================
    public Producto obtenerPorId(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con id: " + id));
    }

    // ===============================
    // ELIMINAR POR ID
    // ===============================
    public void eliminar(Long id) {
        if (!repo.existsById(id)) {
            throw new RuntimeException("Producto no existe");
        }
        repo.deleteById(id);
    }
}
