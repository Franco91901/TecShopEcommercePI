package com.example.demo.service;

import com.example.demo.model.Producto;

import java.util.List;
import java.util.Optional;

public interface ProductoService {

    List<Producto> listar();

    Producto guardar(Producto producto);

    Optional<Producto> obtenerPorId(Long id);

    void eliminar(Long id);
}
