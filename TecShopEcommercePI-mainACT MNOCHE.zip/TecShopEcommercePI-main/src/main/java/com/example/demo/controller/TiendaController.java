package com.example.demo.controller;

import com.example.demo.model.Producto;
import com.example.demo.service.ProductoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import java.util.List;

@Controller
@RequestMapping("/tienda")
public class TiendaController {

    private final ProductoService productoService;

    public TiendaController(ProductoService productoService) {
        this.productoService = productoService;
    }

    // 🛒 LISTAR PRODUCTOS EN LA TIENDA
    @GetMapping
    public String tienda(Model model) {

        List<Producto> productos = productoService.listar();
        model.addAttribute("productos", productos);

        return "tienda/index";  // templates/tienda/index.html
    }

    // 🔍 DETALLE DE PRODUCTO
    @GetMapping("/detalle/{id}")
    public String detalle(@PathVariable Long id, Model model) {

        Optional<Producto> productoOpt = productoService.obtenerPorId(id);

        if (productoOpt.isEmpty()) {
            return "redirect:/tienda?error=noExiste";
        }

        model.addAttribute("producto", productoOpt.get());

        return "tienda/detalle"; // templates/tienda/detalle.html
    }
}
