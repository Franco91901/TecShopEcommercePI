package com.example.demo.controller;

import com.example.demo.model.ItemCarrito;
import com.example.demo.model.Producto;
import com.example.demo.service.ProductoService;
import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class CarritoController {

    private final ProductoService productoService;

    public CarritoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    // 🛒 Mostrar carrito
    @GetMapping("/carrito")
    public String verCarrito(HttpSession session, Model model) {

        List<ItemCarrito> carrito = (List<ItemCarrito>) session.getAttribute("carrito");

        if (carrito == null) {
            carrito = new ArrayList<>();
        }

        double total = carrito.stream()
                .mapToDouble(i -> i.getPrecio() * i.getCantidad())
                .sum();

        model.addAttribute("carrito", carrito);
        model.addAttribute("total", total);

        return "carrito/carrito";
    }

    // ➕ Agregar producto al carrito
    @PostMapping("/carrito/agregar")
    public String agregar(
            @RequestParam("id") Long idProducto,
            @RequestParam(value = "cantidad", defaultValue = "1") int cantidad,
            HttpSession session) {

        Optional<Producto> productoOpt = productoService.obtenerPorId(idProducto);

        if (productoOpt.isEmpty()) {
            return "redirect:/tienda?error=noExiste";
        }

        Producto p = productoOpt.get();

        List<ItemCarrito> carrito = (List<ItemCarrito>) session.getAttribute("carrito");

        if (carrito == null) {
            carrito = new ArrayList<>();
        }

        // ✔ Si ya existe, sumar la cantidad
        for (ItemCarrito item : carrito) {
            if (item.getIdProducto().equals(idProducto)) {
                item.setCantidad(item.getCantidad() + cantidad);
                session.setAttribute("carrito", carrito);
                return "redirect:/carrito";
            }
        }

        // ✔ Agregar nuevo producto al carrito
        carrito.add(new ItemCarrito(
                p.getId(),
                p.getNombre(),
                p.getPrecio(),
                cantidad,
                p.getImagen()
        ));

        session.setAttribute("carrito", carrito);

        return "redirect:/carrito";
    }

    // ❌ Eliminar producto del carrito
    @GetMapping("/carrito/eliminar")
    public String eliminar(@RequestParam("id") Long id, HttpSession session) {

        List<ItemCarrito> carrito = (List<ItemCarrito>) session.getAttribute("carrito");

        if (carrito != null) {
            carrito.removeIf(i -> i.getIdProducto().equals(id));
            session.setAttribute("carrito", carrito);
        }

        return "redirect:/carrito";
    }
}
